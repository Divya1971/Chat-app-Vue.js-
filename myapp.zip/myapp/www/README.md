# Framework7 Vue Template

Simple Framework7 + Vue setup in a single HTML file

This template is targeted at beginners who want to start exploring Framework7 + Vue without the distraction of a complicated development environment.

For advanced features such as asset compilation, hot-reload and CSS extraction, we recommend that more experienced developers use one of the other templates: [Framework7 Vue Webpack Template](https://github.com/nolimits4web/Framework7-Vue-Webpack-Template) or [Framework7 Vue Browserify Template](https://github.com/nolimits4web/Framework7-Vue-Browserify-Template).
